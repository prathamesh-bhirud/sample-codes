import { Action } from '@ngrx/store';

export const JAVA = 'Java';
export const ANGULAR = 'Angular';
export const MY_ARTICLES = 'Favourite_Articles';

