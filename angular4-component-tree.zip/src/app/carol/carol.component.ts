import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carol',
  templateUrl: './carol.component.html',
  styleUrls: ['./carol.component.css']
})
export class CarolComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
