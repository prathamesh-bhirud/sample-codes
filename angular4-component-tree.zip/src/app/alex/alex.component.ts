import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alex',
  templateUrl: './alex.component.html',
  styleUrls: ['./alex.component.css']
})
export class AlexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
