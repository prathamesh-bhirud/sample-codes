import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cathy',
  templateUrl: './cathy.component.html',
  styleUrls: ['./cathy.component.css']
})
export class CathyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
