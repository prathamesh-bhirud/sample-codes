import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-craig',
  templateUrl: './craig.component.html',
  styleUrls: ['./craig.component.css']
})
export class CraigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
