export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyC7dbAJZI0lNdED206t0MPrzrWzlPBybqc",
    authDomain: "angular-firebase-bootstr-dbe05.firebaseapp.com",
    databaseURL: "https://angular-firebase-bootstr-dbe05.firebaseio.com",
    projectId: "angular-firebase-bootstr-dbe05",
    storageBucket: "angular-firebase-bootstr-dbe05.appspot.com",
    messagingSenderId: "496045587882"
  }
};