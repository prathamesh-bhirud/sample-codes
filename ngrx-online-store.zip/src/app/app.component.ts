import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'ngrx-online-store';
  cart: Observable<Array<any>>

  constructor(private store: Store<any>){}

  ngOnInit(){
    this.cart = this.store.select('cart');
  }
}
