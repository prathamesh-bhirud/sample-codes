import { Component} from '@angular/core';

@Component({
  selector: 'app-viewchild-child',
  template: `
  `
})
export class ChildViewchildComponent {

  message = 'Hola Mundo!';

  constructor() { }

}