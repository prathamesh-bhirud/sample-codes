export interface IMarker {
    lat: number;
    lng: number;
    label?: string;
    draggable: boolean;
  }