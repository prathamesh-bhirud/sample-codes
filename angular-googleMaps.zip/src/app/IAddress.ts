export interface IAddress{
    lat: number;
    lng: number;
}

export class Address implements IAddress{
    lat: number;
    lng: number; 
}