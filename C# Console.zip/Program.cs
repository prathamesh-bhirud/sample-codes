﻿using System;
using System.IO;

namespace C__Console
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
            {
                Console.WriteLine("Hello World!");
                File.Copy("a.txt", "b.txt");
                Console.WriteLine(File.ReadAllText("a.txt"));
                Console.WriteLine(File.ReadAllText("b.txt"));
                File.Delete("b.txt");
            }
        }
    }
}
