

export interface Lesson {
    id: string;
    description: string;
    duration: string;
    seqNo: number;
    courseId: number;
}