export interface Computer {
    getComputerName();
}