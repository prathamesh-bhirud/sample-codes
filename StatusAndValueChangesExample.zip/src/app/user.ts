export class User {
    username: string;
    password: string;    
    notificationMode: string;
    email: string;
    mobileNumber: string;
    favoriteLocations: string[];
} 