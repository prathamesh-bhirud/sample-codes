export interface ICounter {
    readonly currentValue: number;
}
