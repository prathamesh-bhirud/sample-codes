import { ICounter } from './ICounter';

export interface IAppState {
  readonly counter: ICounter;
}
