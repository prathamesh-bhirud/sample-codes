import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ic3',
  templateUrl: './ic3.component.html',
  styleUrls: ['./ic3.component.css']
})
export class Ic3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
