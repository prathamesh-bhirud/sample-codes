import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ic4',
  templateUrl: './ic4.component.html',
  styleUrls: ['./ic4.component.css']
})
export class Ic4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
