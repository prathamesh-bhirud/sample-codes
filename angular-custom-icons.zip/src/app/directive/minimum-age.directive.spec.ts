import { MinimumAgeDirective } from './minimum-age.directive';

describe('MinimumAgeDirective', () => {
  it('should create an instance', () => {
    const directive = new MinimumAgeDirective();
    expect(directive).toBeTruthy();
  });
});
